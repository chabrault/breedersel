## commandes pour compiler un Docker file ##
### 1. Produire une image docker dans un répertoire (ici deploy), deux images : Dockerfile_base et Dockerfile

### 2. Ouvrir l'application Docker Desktop

### 3. Modifier la première ligne du fichier Dockerfile_base :
RUN apt-get update -y && apt-get install -y  libicu-dev pandoc make apt-transport-https make  libssl-dev libicu-dev  libcurl4-openssl-dev libssl-dev make zlib1g-dev  make  git libcurl4-openssl-dev libssl-dev  libcurl4-openssl-dev libssl-dev  zlib1g-dev  libicu-dev libcurl4-openssl-dev libssl-dev pandoc make zlib1g-dev  make zlib1g-dev  git libgit2-dev libcurl4-openssl-dev libssl-dev  libfontconfig1-dev libfreetype6-dev  git  libicu-dev  pandoc  cmake make  libssl-dev libfontconfig1-dev libfreetype6-dev cmake make libicu-dev  libssl-dev  libicu-dev libcurl4-openssl-dev libssl-dev zlib1g-dev make  libxml2-dev libicu-dev pandoc make  libicu-dev pandoc make zlib1g-dev  git libgit2-dev libcurl4-openssl-dev libssl-dev make  libxml2-dev && rm -rf /var/lib/apt/lists/*
/var/lib/apt/lists/*

### 4. Se mettre dans le répertoire en question, ouvrir un Powershell, exécuter la commande "bash" et taper :
docker build -f Dockerfile_base --progress=plain -t fto_base .
docker build -f Dockerfile_base --progress=plain -t vitis_explo_base .


### 5. Changer dans le fichier Dockerfile FilesToOpenSilex en fto (première ligne)
FROM fto_base

### 6. Faire tourner le second Docker file
docker build -f Dockerfile --progress=plain -t fto:latest .
docker build -f Dockerfile --progress=plain -t vitis_explo_base:latest .

### 7. Vérifier que le port 80:80 soit disponible dans le logiciel Docker, supprimer les containers qui utilisent ce port (dans Docker Desktop)

### 8. Déployer l'image sur un port local (par défaut 38:38 pour golem)
docker run -p 3838:3838 fto:latest  
docker run -p 3838:3838 vitis_explo_base:latest

### 9. Se rendre à l'adresse 127.0.0.1:3838(8080) pour voir l'application
127.0.0.1:8080
